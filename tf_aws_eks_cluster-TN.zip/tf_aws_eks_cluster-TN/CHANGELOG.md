# Changelog

## v2.2.0
Added Cognito MFA preference permissions


## v2.1.1
Added support for newer tf versions


## v2.1.0
Added resources tagging support


## v2.0.0
Upgraded module to terraform 0.15


## v1.2.0
Added conditional deployment flag


## v1.1.1
Fixed public_access_cidrs input type


## v1.1.0
Added automated changelog and release, and fixed some sec findings
* Fixed some security findings
* Added automated changelog update based on git commit messages
* Tag release on merge

## v1.0.1
- Fixed kubeconfig helm dependency

## v1.0.0
- Added cloudwatch container insights and fixed prometheus dashboard
- Initial version
